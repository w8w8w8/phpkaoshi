<?php

return [
    'Deletetime' => '删除时间',
    'Createtime' => '添加时间',
    'Subject_name' => '科目名称',
   

];

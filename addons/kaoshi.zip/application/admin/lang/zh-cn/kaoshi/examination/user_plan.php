<?php

return [
    'Status'   => '状态',
    'User_id'=>'用户ID',
    'Username'=>'用户名',
    'Plan_id'=>'计划ID',
    'Plan_name'=>'计划名称',
    'Exam_name'=>'试卷名称',
    'Status 0' => '未完成',
    'Status 1' => '已完成',
    'Type'       => '类型',
    'Type 0'     => '正式',
    'Type 1'     => '学习',
];

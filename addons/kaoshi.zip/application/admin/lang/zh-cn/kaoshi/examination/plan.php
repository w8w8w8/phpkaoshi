<?php

return [
    'Subject_id' => '科目ID',
    'Exam_id'    => '试卷ID',
    'user_ids'    => '参与学生',
    'Exam_name'    => '试卷名',
    'Subject_name'    => '科目名',
    'Plan_name'  => '名称',
    'Type'       => '类型',
    'Type 0'     => '正式',
    'Type 1'     => '学习',
    'Times'     => '考试次数',
    'Hours'     => '时长(单位:分钟)',
    'Starttime'  => '开始时间',
    'Endtime'    => '结束时间',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'student_num' => '应参与人数',
    'real_num' => '开始人数',
];

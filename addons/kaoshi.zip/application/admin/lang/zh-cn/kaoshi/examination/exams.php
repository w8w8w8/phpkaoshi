<?php

return [
    'Id'         => 'ID',
    'Admin_id'   => '管理员ID',
    'username'   => '管理员名称',
    'Subject_id' => '科目ID',
    'Subject_name' => '科目名称',
    'Exam_name'  => '卷名',
    'Setting'    => '考卷设置',
    'Questions'  => '考卷题目',
    'Score'      => '总分',
    'Pass'      => '及格线',
    'Type'       => '类型',
    'Type 1'     => '随机组卷',
    'Type 2'     => '自定义组卷',
    'Keyword'    => '关键字',
    'Status'     => '状态',
    'Level 1'      => '易',
    'Level 2'      => '中',
    'Level 3'      => '难',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间'
];

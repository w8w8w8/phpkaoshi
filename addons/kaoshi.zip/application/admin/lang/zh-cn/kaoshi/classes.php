<?php

return [
    'Deletetime' => '删除时间',
    'Createtime' => '添加时间',
    'class_name' => '班级名称',

];
